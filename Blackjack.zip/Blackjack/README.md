# Text-based Blackjack Project v1.1
    A bare-bones text-based game of blackjack, written in Java.
    I would like to periodically come back to this project
    and add to it while also learning Github along the way.

    Code will only run in IDE or Terminal
    No documentation as of yet. I am lazy.
![](BlackJackOutputGif.gif)
<br/>
<br/>"Red Five standing by."